// Copyright Epic Games, Inc. All Rights Reserved.

#include "GC_UE4CPP.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GC_UE4CPP, "GC_UE4CPP" );
